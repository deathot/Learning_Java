package com.example.mybatistest;

import com.example.mybatistest.entity.User;
import com.example.mybatistest.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;


@SpringBootTest

public class test111 {

    @Autowired
    private UserMapper userMapper;
    
    @Test
    public void testSelectList(){
        List<User> list = userMapper.selectList(null);
        list.forEach(System.out::println);
    }
}
