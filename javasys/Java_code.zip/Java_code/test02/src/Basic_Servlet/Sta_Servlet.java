package Basic_Servlet;

import com.sun.net.httpserver.HttpServer;
/*
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = "/")
public class Sta_Servlet extends HttpServlet {
    protected  void doGet (HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {

        // set resp type
        resp.setContentType("text/html");

        //get writer
        PrintWriter pw = resp.getWriter();

        //write resp
        pw.write("<h1>Hello, World!</h1>");
        pw.flush();
    }
}
*/