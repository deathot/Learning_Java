package com.example.mav01.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.mav01.entity.Dict;

public interface DictMapper extends BaseMapper<Dict>{
}
