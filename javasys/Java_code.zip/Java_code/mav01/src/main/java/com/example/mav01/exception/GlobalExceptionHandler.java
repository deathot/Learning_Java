package com.example.mav01.exception;

import com.example.mav01.common.Result;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import java.security.Provider;

@ControllerAdvice

public class GlobalExceptionHandler {
    @ExceptionHandler(ServiceException.class)

    @ResponseBody
    public Result handle(ServiceException se) {
        return Result.error(se.getCode(), se.getMessage());
    }
}
