package com.example.mav01.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.mav01.entity.User;
import org.apache.ibatis.annotations.*;


public interface UserMapper extends BaseMapper<User> {
    /*
    @Select("select * from sys_user")
    List<User> findAll();

    @Insert("insert into sys_user(username,password,email,phone,nickname,address) " +
            "VALUES(#{username},#{password},#{email},#{phone},#{nickname},#{address});")
    int insert(User user);


    @Update("update sys_user set username=#{username}, password=#{password},"+
            "nickname=#{nickname},email=#{email},phone=#{phone},address=#{address} where id=#{id}")


    int update(User user);

    @Delete("delete from sys_user where id=#{id}")
    int deleteById(@Param("id") Integer id);

    @Select("select * from sys_user where username like #{userName} limit #{pageNum},#{pageSize}")
    List<User> selectPage(Integer pageNum, Integer pageSize, String userName);

    @Select("select count(*) from sys_user where username like #{userName}")
    Integer selectTotal(String userName);
    */
}