package com.example.mav01.controller;




import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mav01.entity.Book;
import com.example.mav01.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/book")
public class BookController {

    @GetMapping("/")
    public List<Book> findAll(){
        return bookService.list();
    }

    @Autowired
    private BookService bookService;
    @PostMapping
    public Boolean save(@RequestBody Book book) {
        return bookService.saveBook(book);
    }

    @DeleteMapping("/{id}")
    public Boolean deleteById(@PathVariable Integer id) {
        return bookService.removeById(id);
    }

    //Delete multiple
    @PostMapping("/del/batch/")
    public boolean deleteBatch(@RequestBody List<Integer> ids) {
        return bookService.removeByIds(ids);
    }

    @GetMapping("/{id}")
    public Book findOne(@PathVariable Integer id) {
        return bookService.getById(id);
    }

    @GetMapping("/page")
    public IPage<Book> findPage(@RequestParam Integer pageNum,
                                @RequestParam Integer pageSize,
                                @RequestParam(defaultValue = "") String bookname,
                                @RequestParam(defaultValue = "") String list,
                                @RequestParam(defaultValue = "") String event,
                                @RequestParam(defaultValue = "") String address)
    {
        IPage<Book> page=new Page<>(pageNum,pageSize);
        QueryWrapper<Book> queryWrapper=new QueryWrapper<>();
        queryWrapper.like("bookname",bookname);
        queryWrapper.like("list",list);
        queryWrapper.like("address",address);
        queryWrapper.like("event",event);
        return bookService.page(page,queryWrapper);
    }
}