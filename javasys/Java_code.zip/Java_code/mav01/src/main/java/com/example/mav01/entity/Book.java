package com.example.mav01.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("sys_book")

public class Book {
    @TableId(value = "id",type = IdType.AUTO)
    private Integer id;
    private String bookname;
    private String list;
    private String event;
    private String address;
}
