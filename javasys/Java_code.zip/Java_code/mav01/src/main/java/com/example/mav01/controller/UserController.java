package com.example.mav01.controller;


import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.mav01.common.Constants;
import com.example.mav01.common.Result;
import com.example.mav01.controller.dto.UserDTO;
import com.example.mav01.entity.User;
import com.example.mav01.mapper.UserMapper;
import com.example.mav01.service.UserService;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/user")
public class UserController {

    @GetMapping("/")
    public List<User> findAll(){
        return userService.list();
    }

    @Autowired
    private UserService userService;
    @PostMapping
    public Boolean save(@RequestBody User user) {
        return userService.saveUser(user);
    }

    @DeleteMapping("/{id}")
    public Boolean deleteById(@PathVariable Integer id) {
        return userService.removeById(id);
    }

    //Delete multiple
    @PostMapping("/del/batch/")
    public boolean deleteBatch(@RequestBody List<Integer> ids) {
        return userService.removeByIds(ids);
    }

    @GetMapping("/{id}")
    public User findOne(@PathVariable Integer id) {
        return userService.getById(id);
    }

    @GetMapping("/page")
    public IPage<User> findPage(@RequestParam Integer pageNum,
                                @RequestParam Integer pageSize,
                                @RequestParam(defaultValue = "") String username,
                                @RequestParam(defaultValue = "") String email,
                                @RequestParam(defaultValue = "") String nickname,
                                @RequestParam(defaultValue = "") String address)
    {
        IPage<User> page=new Page<>(pageNum,pageSize);
        QueryWrapper<User> queryWrapper=new QueryWrapper<>();
        queryWrapper.like("username",username);
        queryWrapper.like("nickname",nickname);
        queryWrapper.like("address",address);
        queryWrapper.like("email",email);
        return userService.page(page,queryWrapper);
    }

    @PostMapping("/login")
    public Result login(@RequestBody UserDTO userDTO){
        String username=userDTO.getUsername();//先对userDTO进行是否为空的校验
        String password=userDTO.getPassword();
        //调用hutool工具中的StrUtil函数实现用户名和密码是否为空的判断
        if(StrUtil.isBlank(username) || StrUtil.isBlank(password)){
            return Result.error(Constants.CODE_400,"参数错误");
        }
        UserDTO dto=userService.login(userDTO);
        return Result.success(dto);
    }


    /*
    requestMapping("/test")

    public String login() {
        return "main.html";
    }

    @GetMapping("/")
    Map fun
    public String index(Map<String, Object> map){
        map.put("msg", "Hello, Spring Boot!");
        return "login.html"
    }

    Model fun
    public String index(Model model) {
        model.addAttribute("msg", "Hello, World!");
        return "login.html";
    }

    @PostMapping("/login")
    public String login(String username, String password) {
        System.out.println("Username:" + username + " Pass:" + password);
        return "main.html";
    }

    @Autowired
    private UserMapper userMapper;
    @GetMapping("/")
    public List<User> index(){
        return userMapper.findAll();
    }

    @Autowired
    private UserService userService;
    @PostMapping
    public Integer save(@RequestBody User user) {
        return userService.save(user);
    }

    @DeleteMapping("/{id}")
    public Integer deleteById(@PathVariable Integer id) {
        return userService.deleteById(id);
    }

    @GetMapping("/page")
    public Map<String, Object> findPage(@RequestParam Integer pageNum, @RequestParam Integer pageSize, @RequestParam String userName){
        userName = "%" + userName + "%";
        pageNum = (pageNum-1)*pageSize;
        List data = userService.selectPage(pageNum, pageSize, userName);
        Integer total = userMapper.selectTotal(userName);
        Map<String, Object> res = new HashMap<>();
        res.put("data", data);
        res.put("total", total);
        return res;
    }
    */
}
