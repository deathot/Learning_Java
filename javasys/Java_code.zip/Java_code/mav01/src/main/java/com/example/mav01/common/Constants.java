package com.example.mav01.common;

public interface Constants {
    //Success
    String CODE_200 = "200";

    //Param Error
    String CODE_400 = "400";

    //Auo Error
    String CODE_401 = "401";

    //Sys Error
    String CODE_500 = "500";

    //Oth Error
    String CODE_600 = "600";

}
