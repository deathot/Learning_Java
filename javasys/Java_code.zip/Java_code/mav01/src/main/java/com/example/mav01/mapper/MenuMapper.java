package com.example.mav01.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.mav01.entity.Menu;

public interface MenuMapper extends BaseMapper<Menu>{
}