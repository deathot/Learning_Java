package com.example.mav01.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.mav01.entity.Book;

public interface BookMapper extends BaseMapper<Book>{

}
