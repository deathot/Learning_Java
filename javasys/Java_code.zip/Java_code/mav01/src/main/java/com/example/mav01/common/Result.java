package com.example.mav01.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Result {
    //run val
    private String code;

    //result for front
    private String msg;

    //back data
    private Object data;

    public static Result success() {
        //no param result succ
        return new Result(Constants.CODE_200, "", null);
    }

    public static Result success(Object data) {
        //param result succ
        return new Result(Constants.CODE_200, "", data);
    }

    public static Result error(String code, String msg) {
        //result error
        return new Result(code, msg, null);
    }

    public static Result error() {
        //default error
        return new Result(Constants.CODE_500, "Sys Error", null);
    }
}


