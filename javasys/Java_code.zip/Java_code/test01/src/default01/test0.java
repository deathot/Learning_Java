package default01;

public class test0 {
    public static void main(String[] args){
        System.out.print("Hello, World!\n");
    }
}
