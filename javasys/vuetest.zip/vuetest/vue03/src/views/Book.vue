<template>
    <div>
        <div style="padding:10px">
          <el-input style="width:250px" suffix-icon="el-icon-search" placeholder="按书名查询" v-model="bookname"></el-input>
          <el-input style="width:250px" suffix-icon="el-icon-search" placeholder="按借阅状态查询" v-model="event"></el-input>
          <el-input style="width:250px" suffix-icon="el-icon-search" placeholder="按种类查询" v-model="list"></el-input>
          <el-button style="margin-left:5px" type="primary" @click="load">查询</el-button>
          <el-button style="margin-left:5px" type="warning" @click="reset">重置</el-button>

        </div> 
        <div style="margin:10px">
          <el-button type="primary" @click="hanleAdd">添加<i class="el-icon-circle-plus"></i></el-button>
          <el-button type="danger" @click="BatchDel">批量删除<i class="el-icon-remove"></i></el-button>
          <el-button type="primary">导入<i class="el-icon-bottom"></i></el-button>
          <el-button type="primary">导出<i class="el-icon-top"></i></el-button> 
        </div>
        <el-table
          :data="tableData"
          @selection-change="handleSelectionChange"
          style="width: 100%">

          <el-table-column
            type="selection"
            width="55">
          </el-table-column>

          <el-table-column
            prop="id"
            label="ID"
            width="50">
          </el-table-column>
          <el-table-column
            prop="bookname"
            label="Bookname"
            width="270">
          </el-table-column>
          
          <el-table-column
            prop="list"
            widtg="350"
            label="Categories">
          </el-table-column>

          <el-table-column
            prop="event"
            label="Status">
          </el-table-column>

          <el-table-column
            prop="address"
            label="Publisher">
          </el-table-column>
          <el-table-column fixed="right" label="Settings" width="240">                         
          <template slot-scope="scope">
          <el-button type="success" size="small" icon="el-icon-edit" @click="handleEdit(scope.row)">编辑</el-button>
          
          <el-popconfirm
            cancel-button-text='No'
            confirm-button-text='Yes'
            icon="el-icon-info"
            icon-color="blue"
            title="Delete Confirm?"
            @confirm="handleDelete(scope.row.id)"
          >
            <el-button type="danger" size="small" slot="reference" icon="el-icon-delete">删除</el-button>
          </el-popconfirm>

          </template>
          </el-table-column>
        </el-table>

        <div style="padding:10px">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="pageNum"
            :page-sizes="[5, 10, 15, 20]"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
          </el-pagination>
        </div>

        <el-dialog title="INFO" :visible.sync="dialogFormVisible" width="30%">
            <el-form label-width="80px" size="small">
              <el-form-item label="Bookname">
                <el-input v-model="form.bookname" autocomplete="off"></el-input>
              </el-form-item>          
            
              <el-form-item label="Categories">
                <el-input v-model="form.list" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="Status">
                <el-input v-model="form.event" autocomplete="off"></el-input>
              </el-form-item>  
              <el-form-item label="Publisher">
                <el-input v-model="form.address" autocomplete="off"></el-input>
              </el-form-item>                                
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogFormVisible = false">Cancle</el-button>
              <el-button type="primary" @click="insert">Save</el-button>
            </div>
        </el-dialog>  
    </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
import { Button } from 'element-ui'
import Aside from '@/components/Aside.vue'
import Header from '@/components/Header.vue'
  
  export default {
    name: 'Book',

    data(){    
        return {
          tableData:[],
          total:0,
          pageNum:1,
          pageSize:5,
          bookname:"",
          list:"",
          address:"",
          event: "",
          dialogFormVisible:false,
          form:{},
          multipleSelection: []
        }
    },

    created(){
      //请求分页查询数据
      this.load();
    },

    methods: {
      edit(row){
      console.log(row);
      },  

      handleSizeChange(val) {/*传递过来当前是第几页*/
        console.log(`每页 ${val} 条`);
        this.pageSize=val;  //获取当前每页显示条数
        this.load();
      },

      handleCurrentChange(val) {/*传递过来当前是第几页*/
        console.log(`当前页: ${val}`);
        this.pageNum=val;   //获取当前第几页
        this.load();
      },

      hanleAdd(){
      this.dialogFormVisible = true;
      this.form={};//如果之前有填过值，可以置空
      },

      //将请求数据封装为一个方法
      load() {
      //请求分页查询数据
        //fetch("http://localhost:8084/user/page?pageNum="+this.pageNum+"&pageSize="+this.pageSize+"").then(res=>res.json()).then(res=>{
        //使用axios封装的request        
        this.request.get("/book/page",{
        params:{
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          bookname: this.bookname,
          list: this.list,
          address: this.address,
          event: this.event
        }
        }).then(res=>{
        console.log(res)
        this.tableData=res.records
        this.total=res.total
        })
      },

      reset() {
      this.bookname = "";
      this.list = "";
      this.address = "";
      this.event = "";
      this.load();
      },

      insert(){
        this.request.post("http://localhost:8084/book",this.form).then(res=>{
          if(res){
            this.$message.success("Success");
            this.dialogFormVisible=false;
            this.load();
          }else{
            this.$message.error("Failed");
          }
        })
      },

      handleEdit(row) {
        console.log(row);
        //当前行数据row赋值给form
        this.form = row;
        this.dialogFormVisible = true;
      },

      handleDelete(id) {
        this.request.delete("http://localhost:8084/book/"+id+"").then(res => {
          if(res) {
            this.$message.success("Success!");
            this.load();
          } else {
            this.$message.error("Error!");
          }
        })
      },

      handleSelectionChange(val) {
        console.log(val);
        this.multipleSelection = val;
      },

      BatchDel(){ 
          //map实现multipleSelection中的对象扁平化处理。
          let ids=this.multipleSelection.map(v=>v.id);
          console.log(ids);
          this.request.post("http://localhost:8084/book/del/batch/",ids).then(res=>{
          if(res){
              this.$message.success("BatchDele Success!");
              this.load();
            }else{
              this.$message.error("BatchDel Failed!");
            } 
          })
        },

    },
  }

</script>
