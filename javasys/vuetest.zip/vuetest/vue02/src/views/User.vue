<template>
    <div>
        <div style="padding:10px">
          <el-input style="width:250px" suffix-icon="el-icon-search" placeholder="Search for name" v-model="username"></el-input>
          <el-input style="width:250px" suffix-icon="el-icon-search" placeholder="Search for email" v-model="email"></el-input>
          <el-input style="width:250px" suffix-icon="el-icon-search" placeholder="Search for nickname" v-model="nickname"></el-input>
          <el-button style="margin-left:5px" type="primary" @click="load">Search</el-button>
          <el-button style="margin-left:5px" type="warning" @click="reset">Reset</el-button>

        </div> 
        <div style="margin:10px">
          <el-button type="primary" @click="hanleAdd">Add<i class="el-icon-circle-plus"></i></el-button>
          <el-button type="danger" @click="BatchDel">Batch delete<i class="el-icon-remove"></i></el-button>
          <el-button type="primary">In<i class="el-icon-bottom"></i></el-button>
          <el-button type="primary">Out<i class="el-icon-top"></i></el-button> 
        </div>
        <el-table
          :data="tableData"
          @selection-change="handleSelectionChange"
          style="width: 100%">

          <el-table-column
            type="selection"
            width="55">
          </el-table-column>

          <el-table-column
            prop="id"
            label="ID"
            width="80">
          </el-table-column>
          <el-table-column
            prop="username"
            label="Name"
            width="80">
          </el-table-column>
          <el-table-column
            prop="email"
            label="Email"
            width="120">
          </el-table-column>
          <el-table-column
            prop="phone"
            label="Phone">
          </el-table-column>
          <el-table-column
            prop="nickname"
            label="Nickname">
          </el-table-column>
          <el-table-column
            prop="address"
            label="Address">
          </el-table-column>
          <el-table-column fixed="right" label="Settings" width="240">                         
          <template slot-scope="scope">
          <el-button type="success" size="small" icon="el-icon-edit" @click="handleEdit(scope.row)">Edit</el-button>
          
          <el-popconfirm
            cancel-button-text='No'
            confirm-button-text='Yes'
            icon="el-icon-info"
            icon-color="blue"
            title="Delete Confirm?"
            @confirm="handleDelete(scope.row.id)"
          >
            <el-button type="danger" size="small" slot="reference" icon="el-icon-delete">Delete</el-button>
          </el-popconfirm>

          </template>
          </el-table-column>
        </el-table>

        <div style="padding:10px">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="pageNum"
            :page-sizes="[5, 10, 15, 20]"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
          </el-pagination>
        </div>

        <el-dialog title="INFO" :visible.sync="dialogFormVisible" width="30%">
            <el-form label-width="80px" size="small">
              <el-form-item label="Username">
                <el-input v-model="form.username" autocomplete="off"></el-input>
              </el-form-item>          
              <el-form-item label="Nickname">
                <el-input v-model="form.nickname" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="Email">
                <el-input v-model="form.email" autocomplete="off"></el-input>
              </el-form-item>
              <el-form-item label="Phone">
                <el-input v-model="form.phone" autocomplete="off"></el-input>
              </el-form-item>  
              <el-form-item label="Address">
                <el-input v-model="form.address" autocomplete="off"></el-input>
              </el-form-item>                                
            </el-form>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogFormVisible = false">Cancle</el-button>
              <el-button type="primary" @click="insert">Confirm</el-button>
            </div>
        </el-dialog>  
    </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
import { Button } from 'element-ui'
import Aside from '@/components/Aside.vue'
import Header from '@/components/Header.vue'
  
  export default {
    name: 'User',

    data(){    
        return {
          tableData:[],
          total:0,
          pageNum:1,
          pageSize:5,
          username:"",
          email:"",
          address:"",
          nickname: "",
          dialogFormVisible:false,
          form:{},
          multipleSelection: []
        }
    },

    created(){
      //请求分页查询数据
      this.load();
    },

    methods: {
      edit(row){
      console.log(row);
      },  

      handleSizeChange(val) {/*传递过来当前是第几页*/
        console.log(`每页 ${val} 条`);
        this.pageSize=val;  //获取当前每页显示条数
        this.load();
      },

      handleCurrentChange(val) {/*传递过来当前是第几页*/
        console.log(`当前页: ${val}`);
        this.pageNum=val;   //获取当前第几页
        this.load();
      },

      hanleAdd(){
      this.dialogFormVisible = true;
      this.form={};//如果之前有填过值，可以置空
      },

      //将请求数据封装为一个方法
      load() {
      //请求分页查询数据
        //fetch("http://localhost:8084/user/page?pageNum="+this.pageNum+"&pageSize="+this.pageSize+"").then(res=>res.json()).then(res=>{
        //使用axios封装的request        
        this.request.get("/user/page",{
        params:{
          pageNum: this.pageNum,
          pageSize: this.pageSize,
          username: this.username,
          email: this.email,
          address: this.address,
          nickname: this.nickname
        }
        }).then(res=>{
        console.log(res)
        this.tableData=res.records
        this.total=res.total
        })
      },

      reset() {
      this.username = "";
      this.email = "";
      this.address = "";
      this.nickname = "";
      this.load();
      },

      insert(){
        this.request.post("http://localhost:8084/user",this.form).then(res=>{
          if(res){
            this.$message.success("Success!");
            this.dialogFormVisible=false;
            this.load();
          }else{
            this.$message.error("Failed!");
          }
        })
      },

      handleEdit(row) {
        console.log(row);
        //当前行数据row赋值给form
        this.form = row;
        this.dialogFormVisible = true;
      },

      handleDelete(id) {
        this.request.delete("http://localhost:8084/user/"+id+"").then(res => {
          if(res) {
            this.$message.success("Success!");
            this.load();
          } else {
            this.$message.error("Error!");
          }
        })
      },

      handleSelectionChange(val) {
        console.log(val);
        this.multipleSelection = val;
      },

      BatchDel(){ 
          //map实现multipleSelection中的对象扁平化处理。
          let ids=this.multipleSelection.map(v=>v.id);
          console.log(ids);
          this.request.post("http://localhost:8084/user/del/batch/",ids).then(res=>{
          if(res){
              this.$message.success("BatchDele Success!");
              this.load();
            }else{
              this.$message.error("BatchDel Failed!");
            } 
          })
        },

    },
  }

</script>
