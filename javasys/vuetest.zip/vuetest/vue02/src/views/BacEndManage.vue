<template>
  <div class="home">
  <el-container>
    <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
      <Aside></Aside>
    </el-aside>
    <el-container style="height: 100%; border: 1px solid #eee">
      <el-header style="text-align: right; font-size: 12px; border-bottom: 1px solid black; line-height:60px">
        <Header name="J7_Manager"/>
      </el-header>
      <el-main>
        <router-view/>
      </el-main>
    </el-container>
  </el-container>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
import { Button } from 'element-ui'
import Aside from '@/components/Aside.vue'
import Header from '@/components/Header.vue'
  
  export default {
    name: 'BacEndManage',

    components: {
      HelloWorld,
      Aside,
      Header,

    },
  }
</script>

<style>  
  .el-main {
    text-align: left;
  }
</style>