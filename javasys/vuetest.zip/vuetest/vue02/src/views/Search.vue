<template>
        <img src="../assets/searchpic.png" style="width: 100%;position:relative;top:100%px;margin-right:100%px"/>
</template>


<script>
export default {
    //IO pro
    name: "Search"

}
</script>

<style scope>

</style>