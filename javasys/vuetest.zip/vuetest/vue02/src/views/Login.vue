<template>
 <div class="login_container">
    <div class="login_box">
      <div style="margin:20px 0; text-align:center; font-size:24px"><b>登录</b></div>
      <!--username-->
      <el-form ref="LoginFormRef" :model="loginForm" :rules="LoginFormRules" >
        <el-form-item prop="username">
          <el-input size="medium" style="margin:10px 0px;width: 300px;margin-left:25px" v-model="loginForm.username" prefix-icon="el-icon-user"></el-input>
        </el-form-item>
      <!--password-->
         <el-form-item prop="password">
           <el-input size="medium" style="margin:10px 0px;width: 300px;margin-left:25px" show-password v-model="loginForm.password" prefix-icon="el-icon-lock" type="password"></el-input>
        </el-form-item>
        <div style="margin:10px 0; text-align:center">
          <el-button type="primary" size="small" @click="login" >Login</el-button>
          <el-button type="warning" size="small" @click="resetLoginForm">Reset</el-button>
        </div> 
      </el-form> 
    </div>
  </div>
</template>

<script>

  export default {
    name: "Login",
    data() {
      return {
        loginForm: {
          username:'',
          password:''
        },

        LoginFormRules:{
          username:[
            { required: true, message: 'Please enter username', trigger: 'blur' },
          ],

          password:[
            { required: true, message: 'please enter password', trigger: 'blur' },
          ]
        }

      }
    },
    
    methods:{
      login() {
            this.$router.push("/home");
            this.$message.success("Sign in success!");
        },

      resetLoginForm(){
        this.$refs.LoginFormRef.resetFields()
      },

      //   login(){
      //       this.$refs['LoginFormRef'].validate(async (valid) => {
      //           if (valid) {
      //               this.request.post("/user/login",this.loginForm).then(res=>{
	    //                 if(res.code=='200'){
	    //                     localStorage.setItem("user",JSON.stringify(res.data));//存储用户信息到浏览器
	    //                     this.$router.push("/home");
	    //                     this.$message.success("登录成功");
	    //                 }else{
	    //                     this.$message.error(res.msg);
	    //                 }
      //               })
      //           }  
      //       })
      //  },
    }
  }
</script>

<style scoped>
  .login_container{
    width: 100%;
    height: 100%;
    background-color: rgb(23, 37, 77);
    border-radius: 3px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%)
  }

  .login_box{
    width: 60%;
    height: 80%;
    background-color: rgba(31, 29, 29, 0.699);
    border-radius: 3px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%)
  }
</style>