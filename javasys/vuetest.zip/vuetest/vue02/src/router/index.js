import Vue from 'vue'
import VueRouter from 'vue-router'
import BacEndManage from '../views/BacEndManage.vue'
import User from '../views/User.vue'
import Login from '../views/Login.vue'
import Menu from '../views/Menu.vue'
import Book from '../views/Book.vue'
import Search from '../views/Search.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'BacEndManage',
    redirect: '/login',
    component: BacEndManage,
    children:[
      {
        path: "user",
        name: "User",
        component: User
      },
        
      {
        path:'menu',
        name:'Menu',
        component:Menu
      },

      {
        path: 'book',
        name: 'Book',
        component:Book
      },

      {
        path: 'search',
        name: 'Search',
        component:Search
      },

      {
        path: 'home',
        name: 'Home',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () => import(/* webpackChunkName: "about" */ '../views/Home.vue')
      },
      
    ]
  },

  {
    path: '/login',
    name: 'Login',
    component: Login
  },
]


const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
