import axios from 'axios'

const request = axios.create({
    baseURL: 'http://localhost:8084',
    timeout: 5000

})

//headers = {'Content-Type':'application/json;charset=UTF-8'}

//request interceptors 可执行一些前序操作， request发送前做一些处理， 统一加token？
request.interceptors.request.use(config => {
    config.headers =  { 'Content-type' : 'application/json', Accept : 'application/json'};
    //config.headers['token'] = user.token; //set token for headers
    return config

}, error => {
    return Promise.reject(error)

});

//response interceptors 接口响应后处理结果
request.interceptors.response.use(
    response => {
        let res = response.data;

        //如果是blob
        if (response.config.responseType === 'blob') {
            return res

        }
        //serve 返回的 string data
        if (typeof res === 'string') {
            res = res ? JSON.parse(res) : res

        }
        return res;

    },
    error => {
        console.log('err' + error)
        return Promise.reject(error)

    }
)

export default request

