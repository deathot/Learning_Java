<template>
    <el-dropdown style="width: 100px; cursor: pointer">
          <span>{{name}}</span><i class="el-icon-arrow-down" style="margin-left: 5px"></i>
            <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>INFO</el-dropdown-item>
            <el-dropdown-item>
                <span style="text-decoration: none" @click="logout">Exit</span>
            </el-dropdown-item>
            </el-dropdown-menu>
    </el-dropdown>
</template>

<script>
export default {
    name: "Header",
    props: {
        name: String
    },

    data() {
        return {
            user:localStorage.getItem("user")?JSON.parse(localStorage.getItem("user")):{}
        }
    },

    methods: {
        logout() {
            this.$router.push("/login");
            this.$message.success("Exit success!");
        }
    }
}
</script>

<style>

</style>