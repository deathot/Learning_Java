<template>
    <el-menu :default-openeds="['2']" 
    style="min-height:100%; overflow-x:hidden"
    background-color=rgb(48,65,86)
    text-color=#ccc
    active-text-color=black
    router=""
    >
    <div style="height:60px; line-height:60px; text-align:center">
    <img src="../assets/60_60.png" style="width:20px;position:relative;top:5px;margin-right:5px"/>
    <b style="color:dimgray">ManageSys</b>
    </div>
    <el-menu-item index="/home">
      <template slot="title">
        <i class="el-icon-house"></i>
        <span slot="title">Home</span>
      </template>
    </el-menu-item>

    <el-menu-item index="/search">
      <template slot="title">
        <i class="el-icon-s-custom"></i>
        <span >Search</span>  
      </template>      
    </el-menu-item>

    <el-submenu index="2">
      <template slot="title">
        <i class="el-icon-menu"></i>
        <span slot="title">SysManage</span>
      </template>
      <el-menu-item index="/user">
          <i class="el-icon-s-custom"></i>
          <span slot="title">UserManage</span>
      </el-menu-item>    
      
      <el-menu-item index="/menu">
        <template slot="title">
            <i class="el-icon-s-custom"></i>
            <span >MenuManage</span>  
        </template>      
      </el-menu-item>
      
      <el-menu-item index="/book">
        <template slot="title">
          <i class="el-icon-s-custom"></i>
          <span >BookManage</span>  
        </template>      
      </el-menu-item>

    </el-submenu>   
    
</el-menu>
</template>

<script>
export default {
    //IO pro
    name: "Aside"

}
</script>

<style scope>

</style>
