<template>
  <el-form :model="book" label-width="120px">
    <!-- 表单字段 -->
    <el-form-item label="书名">
      <el-input v-model="book.title"></el-input>
    </el-form-item>
    <el-form-item label="作者">
    <el-input v-model="book.author"></el-input>
    </el-form-item>
    <el-form-item label="出版日期">
    <el-input v-model="book.publishDate"></el-input>
    </el-form-item>
    <!-- 其他字段 -->
    <el-form-item>
      <el-button type="primary" @click="submitForm">提交</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
export default {
  data() {
    return {
      book: { title: '', author: '', publishDate: '' } // 初始化表单数据
    }
  },
  methods: {
    submitForm() {
      // 根据book.id是否存在来判断是新增还是编辑
      const action = this.book.id ? 'updateBook' : 'addBook'
      this.$store.dispatch(action, this.book)
    }
  }
}
</script>