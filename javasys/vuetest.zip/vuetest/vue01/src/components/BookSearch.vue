<template>
    <div>
      <el-input v-model="searchQuery" placeholder="请输入书名" @input="searchBooks"></el-input>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        searchQuery: ''
      }
    },
    methods: {
      searchBooks() {
        if (this.searchQuery) {
          this.$store.dispatch('searchBooks', this.searchQuery)
        }
      }
    }
  }
  </script>