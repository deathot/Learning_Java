<template>
  <el-table :data="books" style="width: 100%">
    <el-table-column prop="title" label="书名"></el-table-column>
    <el-table-column prop="author" label="作者"></el-table-column>
    <el-table-column prop="publishDate" label="出版日期"></el-table-column>
    <el-table-column label="操作">
      <template #default="{ row }">
        <el-button type="primary" @click="editBook(row)">编辑</el-button>
        <el-button type="danger" @click="deleteBook(row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
export default {
  computed: {
    books() {
      return this.$store.state.books
    }
  },
  methods: {
    editBook(book) {
      this.$router.push({ name: 'EditBook', params: { id: book.id } })
    },
    deleteBook(book) {
      // 调用API删除图书，并更新状态
      this.$confirm('确定要删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(async () => {
        try {
         this.$store.dispatch('deleteBook', book.id)
          this.$message.success('删除成功');
          this.fetchBooks();
        } catch (error) {
          console.error(error);
          this.$message.error('删除失败');
        }
      }).catch(() => {
        this.$message.info('已取消删除');
      });
    }
    
    }
  }

</script>