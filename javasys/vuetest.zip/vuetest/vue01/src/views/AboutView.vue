<template>
  <div class="searchBooks">
<template>
  <div>
    <h1>图书管理系统</h1>

    <div class="search-bar">
      <input type="text" v-model="searchQuery" placeholder="搜索图书">
      <button @click="searchBooks">搜索</button>
    </div>

    <button @click="addBook">新增图书</button>

    <table>
      <thead>
        <tr>
          <th>书籍ID</th>
          <th>书名</th>
          <th>作者</th>
          <th>价格</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(book) in filteredBooks" :key="book.id">
          <td>{{ book.id }}</td>
          <td>{{ book.title }}</td>
          <td>{{ book.author }}</td>
          <td>{{ book.price }}</td>
          <td>
            <button @click="editBook(book)">编辑</button>
            <button @click="deleteBook(book.id)">删除</button>
          </td>
        </tr>
      </tbody>
    </table>

    <div class="modal" v-if="showAddModal">
      <div class="modal-content">
        <span class="close" @click="showAddModal = false">&times;</span>
        <h2>新增图书</h2>
        <form @submit.prevent="createBook">
          <div class="form-group">
            <label for="title">书名:</label>
            <input type="text" id="title" v-model="newBook.title" required>
          </div>
          <div class="form-group">
            <label for="author">作者:</label>
            <input type="text" id="author" v-model="newBook.author" required>
          </div>
          <div class="form-group">
            <label for="price">价格:</label>
            <input type="number" id="price" v-model="newBook.price" required>
          </div>
          <button type="submit">创建</button>
        </form>
      </div>
    </div>

    <div class="modal" v-if="showEditModal">
      <div class="modal-content">
        <span class="close" @click="showEditModal = false">&times;</span>
        <h2>编辑图书</h2>
        <form @submit.prevent="updateBook">
          <div class="form-group">
            <label for="id">书籍ID:</label>
            <input type="number" id="id" v-model="editBook.id" disabled>
          </div>
          <div class="form-group">
            <label for="title">书名:</label>
            <input type="text" id="title" v-model="editBook.title" required>
          </div>
          <div class="form-group">
            <label for="author">作者:</label>
            <input type="text" id="author" v-model="editBook.author" required>
          </div>
          <div class="form-group">
            <label for="price">价格:</label>
            <input type="number" id="price" v-model="editBook.price" required>
          </div>
          <button type="submit">更新</button>
        </form>
      </div>
    </div>
  </div>
</template>
  </div>
</template>
