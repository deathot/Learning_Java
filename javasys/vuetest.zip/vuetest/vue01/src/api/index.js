import axios from 'axios'

const api = axios.create({
  baseURL: 'http://localhost:8080/books', // 替换为你的后端API地址
  timeout: 1000,
  headers: {'X-Custom-Header': 'foobar'}
})

export const getBooks = () => api.get('/books')
export const addBook = (book) => api.post('/books', book)
export const updateBook = (book) => api.put(`/books/${book.id}`, book)
export const deleteBook = (id) => api.delete(`/books/${id}`)

